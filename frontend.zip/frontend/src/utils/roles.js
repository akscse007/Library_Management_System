export const ROLES = {
  STUDENT: "student",
  LIBRARIAN: "librarian",
  MANAGER: "manager",
  ACCOUNTANT: "accountant",
  STOCK_MANAGER: "stock_manager",
  SUPPLIER: "supplier_contact",
  ADMIN: "admin",
};
